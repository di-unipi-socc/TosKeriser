# Proxy

**requirements**:
- go:1.8

## Getting Started

Install neat tools and dependencies.

```
make deps && make restore
```

Build the app.

```
make build
```
